<?php
defined('MOODLE_INTERNAL') || die();

function local_lessonmanagement_extend_navigation_course($navigation, $course, $context) {
    global $CFG;

    if (has_capability('local/lessonmanagement:manage', $context)) {
        $url = new moodle_url('/local/lessonmanagement/manage.php');
        $navigation->add(get_string('manage_lessons', 'local_lessonmanagement'), $url, navigation_node::TYPE_SETTING, null, 'manage_lessons');
    }
}

function local_lessonmanagement_extend_settings_navigation(settings_navigation $nav, context $context) {
    global $CFG;

    if (has_capability('local/lessonmanagement:manage', $context)) {
        $url = new moodle_url('/local/lessonmanagement/manage.php');
        $nav->add(get_string('manage_lessons', 'local_lessonmanagement'), $url, settings_navigation::TYPE_CONTAINER);
    }
}
