<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Lesson Management';
$string['manage_lessons'] = 'Manage Lessons';
$string['username'] = 'Username';
$string['grant_teacher_permissions'] = 'Grant Teacher Permissions';
$string['revoke_teacher_permissions'] = 'Revoke Teacher Permissions';
