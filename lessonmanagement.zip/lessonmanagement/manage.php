<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

if (!isloggedin() || !has_capability('local/lessonmanagement:manage', context_system::instance())) {
    redirect($CFG->wwwroot);
}

$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('pluginname', 'local_lessonmanagement'));
$PAGE->set_heading(get_string('pluginname', 'local_lessonmanagement'));
$PAGE->navbar->add(get_string('manage_lessons', 'local_lessonmanagement'));

echo $OUTPUT->header();

if (isset($_POST['username']) && isset($_POST['action'])) {
    $username = $_POST['username'];
    $action = $_POST['action'];
    $roleid = 3; // the id of the "teacher" role

    $user = $DB->get_record('user', array('username' => $username));
    if (!$user) {
        echo get_string('invalid_username', 'local_lessonmanagement');
    } else {
        $context = context_user::instance($user->id);
        switch ($action) {
            case 'grant':
                role_assign($roleid, $user->id, $context->id);
                echo get_string('teacher_permissions_granted', 'local_lessonmanagement', $username);
                break;
            case 'revoke':
                role_unassign($roleid, $user->id, $context->id);
                echo get_string('teacher_permissions_revoked', 'local_lessonmanagement', $username);
                break;
            default:
                echo get_string('invalid_action', 'local_lessonmanagement');
                break;
        }
    }
}

$templatecontext = new stdClass();
$templatecontext->hiddenfields = array(
    array('name' => 'sesskey', 'value' => sesskey()),
);
echo $OUTPUT->render_from_template('local_lessonmanagement/manage', $templatecontext);

echo $OUTPUT->footer();
