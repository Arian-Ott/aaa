<?php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot.'/local/lessonmanagement/lib.php');

$context = context_system::instance();
$PAGE->set_context($context);

if (!is_siteadmin()) {
    print_error('accessdenied', 'admin');
}

$PAGE->set_url('/local/lessonmanagement/index.php');
$PAGE->set_heading(get_string('pluginname', 'local_lessonmanagement'));
$PAGE->set_title(get_string('pluginname', 'local_lessonmanagement'));

$lessonmanagement_url = new moodle_url('/local/lessonmanagement/manage.php');
$lessonmanagement_link = html_writer::link($lessonmanagement_url, get_string('manage', 'local_lessonmanagement'));

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('pluginname', 'local_lessonmanagement'));

echo "<p>".get_string('description', 'local_lessonmanagement')."</p>";

echo "<p>".get_string('manageteachers', 'local_lessonmanagement')." $lessonmanagement_link</p>";

echo $OUTPUT->footer();