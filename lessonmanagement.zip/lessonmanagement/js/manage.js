$(document).ready(function() {
    $('#grant-teacher-permissions').click(function() {
        var username = $('#username').val();
        if (username.length > 0) {
            $.ajax({
                type: 'POST',
                url: '/local/lessonmanagement/manage.php',
                data: { username: username, action: 'grant' },
                success: function(response) {
                    alert(response);
                },
               
